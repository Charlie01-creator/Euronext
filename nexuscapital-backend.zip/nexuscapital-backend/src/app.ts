import express, { Express } from 'express';
import path from 'path';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import cookieParser from 'cookie-parser';
import pinoHttp from 'pino-http';
import swaggerUi from 'swagger-ui-express';

import { env } from './config/env';
import { logger } from './config/logger';
import { swaggerSpec } from './config/swagger';
import { generalLimiter } from './middleware/rateLimit.middleware';
import { errorHandler, notFoundHandler } from './middleware/error.middleware';

import authRoutes from './modules/auth/auth.routes';
import usersRoutes from './modules/users/users.routes';
import packagesRoutes from './modules/packages/packages.routes';
import depositsRoutes from './modules/deposits/deposits.routes';
import withdrawalsRoutes from './modules/withdrawals/withdrawals.routes';
import referralsRoutes from './modules/referrals/referrals.routes';
import notificationsRoutes from './modules/notifications/notifications.routes';
import analyticsRoutes from './modules/analytics/analytics.routes';
import securityRoutes from './modules/security/security.routes';
import currencyRoutes from './modules/currency/currency.routes';
import paymentsRoutes from './modules/payments/payments.routes';

export function createApp(): Express {
  const app = express();

  app.use(helmet());
  app.use(cors({ origin: env.CORS_ORIGIN, credentials: true }));
  app.use(compression());
  app.use(cookieParser());
  app.use(express.json({ limit: '1mb' }));
  app.use(express.urlencoded({ extended: true }));
  app.use(pinoHttp({ logger }));
  app.use(generalLimiter);

  app.get('/health', (_req, res) => res.json({ success: true, status: 'ok', timestamp: new Date().toISOString() }));

  // ── Frontend (served from the same origin as the API) ──────────
  const publicDir = path.join(__dirname, '..', 'public');
  app.use(express.static(publicDir));
  app.get('/', (_req, res) => res.sendFile(path.join(publicDir, 'login-1.html')));

  app.use('/docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));
  app.get('/docs.json', (_req, res) => res.json(swaggerSpec));

  const base = env.API_BASE_URL;
  app.use(`${base}/auth`, authRoutes);
  app.use(`${base}/users`, usersRoutes);
  app.use(`${base}/packages`, packagesRoutes);
  app.use(`${base}/deposits`, depositsRoutes);
  app.use(`${base}/withdrawals`, withdrawalsRoutes);
  app.use(`${base}/referrals`, referralsRoutes);
  app.use(`${base}/notifications`, notificationsRoutes);
  app.use(`${base}/analytics`, analyticsRoutes);
  app.use(`${base}/security`, securityRoutes);
  app.use(`${base}/currency`, currencyRoutes);
  app.use(`${base}/payments`, paymentsRoutes);

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}
