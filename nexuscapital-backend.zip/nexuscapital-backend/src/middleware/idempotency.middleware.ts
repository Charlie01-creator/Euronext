import { NextFunction, Request, Response } from 'express';
import { redis } from '../lib/redis';
import { ApiError } from '../utils/ApiError';
import { catchAsync } from '../utils/catchAsync';

const IDEMPOTENCY_TTL_SECONDS = 60 * 10; // 10 minutes

/**
 * Requires an `Idempotency-Key` header on money-movement requests (deposits, withdrawals,
 * package purchases). If the same key is replayed within the TTL window, the request is
 * rejected with 409 instead of silently double-processing the payment.
 */
export const requireIdempotencyKey = catchAsync(async (req: Request, _res: Response, next: NextFunction) => {
  const key = req.headers['idempotency-key'];
  if (!key || typeof key !== 'string') {
    throw ApiError.badRequest('Idempotency-Key header is required for this operation');
  }

  const redisKey = `idempotency:${req.user?.id ?? 'anon'}:${key}`;
  const wasSet = await redis.set(redisKey, '1', 'EX', IDEMPOTENCY_TTL_SECONDS, 'NX');

  if (wasSet === null) {
    throw ApiError.conflict('This request has already been submitted. Please wait before retrying.');
  }

  next();
});
