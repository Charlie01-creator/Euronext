import { v4 as uuid } from 'uuid';
import { prisma } from '../../lib/prisma';
import { redis } from '../../lib/redis';
import { ApiError } from '../../utils/ApiError';
import { comparePassword, generateReferralCode, hashPassword } from '../../utils/password';
import {
  hashToken,
  signAccessToken,
  signRefreshToken,
  verifyRefreshToken,
} from '../../utils/jwt';
import { env } from '../../config/env';
import { logger } from '../../config/logger';
import { LoginInput, RegisterInput } from './auth.validation';
import { createNotification } from '../notifications/notifications.service';

const REFRESH_TOKEN_TTL_SECONDS = 60 * 60 * 24 * 30; // 30 days, mirrors JWT_REFRESH_EXPIRES_IN

function publicUser(user: { id: string; fullName: string; email: string; referralCode: string; defaultCurrency: string; kycStatus: string; twoFactorEnabled: boolean; createdAt: Date }) {
  return {
    id: user.id,
    fullName: user.fullName,
    email: user.email,
    referralCode: user.referralCode,
    defaultCurrency: user.defaultCurrency,
    kycStatus: user.kycStatus,
    twoFactorEnabled: user.twoFactorEnabled,
    memberSince: user.createdAt,
  };
}

async function issueTokenPair(userId: string, email: string) {
  const accessToken = signAccessToken({ sub: userId, email });
  const jti = uuid();
  const refreshToken = signRefreshToken({ sub: userId, jti });

  await prisma.refreshToken.create({
    data: {
      id: jti,
      userId,
      tokenHash: hashToken(refreshToken),
      expiresAt: new Date(Date.now() + REFRESH_TOKEN_TTL_SECONDS * 1000),
    },
  });

  return { accessToken, refreshToken };
}

export async function register(input: RegisterInput) {
  const existing = await prisma.user.findUnique({ where: { email: input.email } });
  if (existing) throw ApiError.conflict('An account with this email already exists');

  let referredById: string | undefined;
  if (input.referralCode) {
    const referrer = await prisma.user.findUnique({ where: { referralCode: input.referralCode } });
    if (!referrer) throw ApiError.badRequest('Invalid referral code');
    referredById = referrer.id;
  }

  const passwordHash = await hashPassword(input.password);

  let referralCode = generateReferralCode(input.fullName);
  // extremely unlikely to collide, but guard against it anyway
  while (await prisma.user.findUnique({ where: { referralCode } })) {
    referralCode = generateReferralCode(input.fullName);
  }

  const user = await prisma.user.create({
    data: {
      fullName: input.fullName,
      email: input.email,
      phone: input.phone,
      country: input.country ?? 'Uganda',
      passwordHash,
      referralCode,
      referredById,
    },
  });

  if (referredById) {
    await prisma.referral.create({
      data: { referrerId: referredById, referredId: user.id, status: 'PENDING' },
    });
    await createNotification({
      userId: referredById,
      type: 'SYSTEM',
      icon: 'fa-user-plus',
      color: 'blue',
      title: 'New referral joined',
      description: `${user.fullName} signed up using your referral link.`,
    });
  }

  const tokens = await issueTokenPair(user.id, user.email);
  return { user: publicUser(user), ...tokens };
}

/** Accepts +256XXXXXXXXX, 256XXXXXXXXX, 0XXXXXXXXX, or bare 9-digit local formats and normalizes to +256XXXXXXXXX. */
function normalizeUgandaPhone(raw: string): string {
  const s = raw.replace(/[\s\-()]/g, '');
  if (s.startsWith('+256')) return s;
  if (s.startsWith('256')) return `+${s}`;
  if (s.startsWith('0')) return `+256${s.slice(1)}`;
  if (/^[27]\d{8}$/.test(s)) return `+256${s}`;
  return s;
}

export async function login(input: LoginInput, context: { ipAddress: string; device: string }) {
  const user = input.email
    ? await prisma.user.findUnique({ where: { email: input.email } })
    : await prisma.user.findUnique({ where: { phone: normalizeUgandaPhone(input.phoneNumber!) } });

  if (!user) throw ApiError.unauthorized('Invalid credentials');

  const valid = await comparePassword(input.password, user.passwordHash);
  if (!valid) throw ApiError.unauthorized('Invalid credentials');

  await prisma.loginActivity.create({
    data: {
      userId: user.id,
      device: context.device,
      ipAddress: context.ipAddress,
    },
  });

  const tokens = await issueTokenPair(user.id, user.email);
  return { user: publicUser(user), ...tokens };
}

export async function refresh(refreshToken: string) {
  let payload;
  try {
    payload = verifyRefreshToken(refreshToken);
  } catch {
    throw ApiError.unauthorized('Invalid or expired refresh token');
  }

  const tokenHash = hashToken(refreshToken);
  const stored = await prisma.refreshToken.findUnique({ where: { tokenHash } });

  if (!stored || stored.revoked || stored.expiresAt < new Date()) {
    throw ApiError.unauthorized('Refresh token has been revoked or expired');
  }

  // rotate: revoke the old token, issue a brand new pair
  await prisma.refreshToken.update({ where: { id: stored.id }, data: { revoked: true } });

  const user = await prisma.user.findUnique({ where: { id: payload.sub } });
  if (!user) throw ApiError.unauthorized('User no longer exists');

  const tokens = await issueTokenPair(user.id, user.email);
  return tokens;
}

export async function logout(refreshToken: string | undefined, userId: string) {
  if (refreshToken) {
    const tokenHash = hashToken(refreshToken);
    await prisma.refreshToken.updateMany({ where: { tokenHash }, data: { revoked: true } });
  }
  // also drop any cached session data for this user
  await redis.del(`session:${userId}`);
}

const RESET_TOKEN_TTL_SECONDS = 60 * 30; // 30 minutes

/**
 * Always resolves successfully regardless of whether the phone number matches an account —
 * this is deliberate (anti-enumeration): a caller should not be able to tell which phone
 * numbers have accounts by watching for different responses.
 */
export async function forgotPassword(phoneNumber: string) {
  const normalized = normalizeUgandaPhone(phoneNumber);
  const user = await prisma.user.findUnique({ where: { phone: normalized } });
  if (!user) return; // silently no-op — same response either way

  const token = uuid();
  await redis.set(`password-reset:${token}`, user.id, 'EX', RESET_TOKEN_TTL_SECONDS);

  // This project doesn't yet integrate an SMS/email provider (e.g. Africa's Talking, since
  // this is a Uganda-focused product) to actually deliver the token to the user — that's a
  // real external account/integration dependency, documented in the README alongside the
  // other out-of-scope integrations (Flutterwave KYB, admin API). Logging it here in the
  // meantime so the flow is fully testable end-to-end in development.
  logger.info({ userId: user.id, token }, 'Password reset token issued — wire up SMS/email delivery before production use');
}

export async function resetPassword(token: string, newPassword: string) {
  const userId = await redis.get(`password-reset:${token}`);
  if (!userId) throw ApiError.badRequest('This reset link is invalid or has expired');

  const passwordHash = await hashPassword(newPassword);
  await prisma.user.update({ where: { id: userId }, data: { passwordHash } });
  await redis.del(`password-reset:${token}`);

  // revoke every existing session — a password reset should log the user out everywhere
  await prisma.refreshToken.updateMany({ where: { userId }, data: { revoked: true } });
}
