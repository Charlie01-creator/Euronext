import { prisma } from '../../lib/prisma';
import { logger } from '../../config/logger';
import { createNotification } from '../notifications/notifications.service';
import { emitToUser } from '../../sockets/socket.server';
import * as flutterwave from './flutterwave.provider';

interface FlutterwaveWebhookPayload {
  event: string;
  data: {
    id: number;
    tx_ref?: string;
    reference?: string;
    status: string;
    amount: number;
    currency: string;
  };
}

export async function handleFlutterwaveWebhook(payload: FlutterwaveWebhookPayload) {
  logger.info({ event: payload.event }, 'Flutterwave webhook received');

  if (payload.event === 'charge.completed') {
    await handleChargeCompleted(payload.data);
  } else if (payload.event === 'transfer.completed') {
    await handleTransferCompleted(payload.data);
  } else {
    logger.info({ event: payload.event }, 'Unhandled Flutterwave webhook event — ignored');
  }
}

async function handleChargeCompleted(data: FlutterwaveWebhookPayload['data']) {
  const providerRef = data.tx_ref;
  if (!providerRef) return;

  const transaction = await prisma.transaction.findUnique({
    where: { providerRef },
    include: { userPackage: true },
  });
  if (!transaction || transaction.status !== 'PENDING') return;

  // Never trust the webhook body alone — re-verify the transaction directly with Flutterwave.
  const verification = await flutterwave.verifyTransaction(String(data.id));
  const isSuccessful = verification.data.status === 'successful';

  await prisma.$transaction(async (tx) => {
    await tx.transaction.update({
      where: { id: transaction.id },
      data: { status: isSuccessful ? 'COMPLETED' : 'FAILED' },
    });

    if (!isSuccessful) {
      if (transaction.userPackageId) {
        await tx.userPackage.update({ where: { id: transaction.userPackageId }, data: { status: 'CANCELLED' } });
      }
      return;
    }

    if (transaction.type === 'DEPOSIT') {
      await tx.user.update({
        where: { id: transaction.userId },
        data: { balanceUsd: { increment: transaction.amountUsd } },
      });
    }

    if (transaction.type === 'PACKAGE_PURCHASE' && transaction.userPackageId) {
      await tx.userPackage.update({ where: { id: transaction.userPackageId }, data: { status: 'ACTIVE' } });

      // referral commission: 7% of the deposit goes to whoever referred this user, once per qualifying deposit
      const buyer = await tx.user.findUnique({ where: { id: transaction.userId } });
      if (buyer?.referredById) {
        const referral = await tx.referral.findUnique({ where: { referredId: buyer.id } });
        if (referral) {
          const commissionAmount = Number(transaction.amountUsd) * 0.07;
          const commissionTx = await tx.transaction.create({
            data: {
              userId: referral.referrerId,
              type: 'COMMISSION',
              status: 'COMPLETED',
              amountUsd: commissionAmount,
            },
          });
          await tx.commission.create({
            data: {
              referralId: referral.id,
              earnerId: referral.referrerId,
              transactionId: commissionTx.id,
              ratePercent: 7,
              amountUsd: commissionAmount,
            },
          });
          await tx.referral.update({ where: { id: referral.id }, data: { status: 'PAID' } });
          await tx.user.update({
            where: { id: referral.referrerId },
            data: { balanceUsd: { increment: commissionAmount } },
          });
        }
      }
    }
  });

  const notifType = transaction.type === 'DEPOSIT' ? 'DEPOSIT' : 'PACKAGE';
  await createNotification({
    userId: transaction.userId,
    type: isSuccessful ? notifType : 'SECURITY',
    icon: isSuccessful ? 'fa-circle-check' : 'fa-triangle-exclamation',
    color: isSuccessful ? 'green' : 'red',
    title: isSuccessful ? 'Payment confirmed' : 'Payment failed',
    description: isSuccessful
      ? `Your payment of $${Number(transaction.amountUsd).toLocaleString()} has been confirmed.`
      : `Your payment of $${Number(transaction.amountUsd).toLocaleString()} could not be completed.`,
  });

  emitToUser(transaction.userId, 'wallet:update', { transactionId: transaction.id, status: isSuccessful ? 'COMPLETED' : 'FAILED' });
}

async function handleTransferCompleted(data: FlutterwaveWebhookPayload['data']) {
  const providerRef = data.reference;
  if (!providerRef) return;

  const transaction = await prisma.transaction.findUnique({ where: { providerRef } });
  if (!transaction || transaction.type !== 'WITHDRAWAL' || transaction.status !== 'PENDING') return;

  const isSuccessful = data.status === 'SUCCESSFUL';

  await prisma.$transaction(async (tx) => {
    await tx.transaction.update({
      where: { id: transaction.id },
      data: { status: isSuccessful ? 'COMPLETED' : 'FAILED' },
    });

    // Balance was deducted up-front when the withdrawal was requested; refund it if the payout failed.
    if (!isSuccessful) {
      await tx.user.update({
        where: { id: transaction.userId },
        data: { balanceUsd: { increment: transaction.amountUsd } },
      });
    }
  });

  await createNotification({
    userId: transaction.userId,
    type: 'WITHDRAWAL',
    icon: isSuccessful ? 'fa-money-bill-transfer' : 'fa-triangle-exclamation',
    color: isSuccessful ? 'gold' : 'red',
    title: isSuccessful ? 'Withdrawal processed' : 'Withdrawal failed',
    description: isSuccessful
      ? `Your withdrawal of $${Number(transaction.amountUsd).toLocaleString()} has been sent.`
      : `Your withdrawal of $${Number(transaction.amountUsd).toLocaleString()} failed and has been refunded to your balance.`,
  });

  emitToUser(transaction.userId, 'wallet:update', { transactionId: transaction.id, status: isSuccessful ? 'COMPLETED' : 'FAILED' });
}
