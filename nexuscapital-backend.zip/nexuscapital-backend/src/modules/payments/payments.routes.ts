import { Request, Response, Router } from 'express';
import { catchAsync } from '../../utils/catchAsync';
import { ApiError } from '../../utils/ApiError';
import * as flutterwave from './flutterwave.provider';
import * as paymentsService from './payments.service';

/**
 * @openapi
 * /payments/webhooks/flutterwave:
 *   post:
 *     tags: [Payments]
 *     summary: Flutterwave webhook receiver (deposits, package purchases, withdrawal payouts)
 *     description: Called by Flutterwave's servers, not by the frontend. Verified via the verif-hash header rather than a user session.
 *     responses:
 *       200: { description: Acknowledged }
 */
const webhookHandler = catchAsync(async (req: Request, res: Response) => {
  const signature = req.headers['verif-hash'] as string | undefined;
  if (!flutterwave.verifyWebhookSignature(signature)) {
    throw ApiError.unauthorized('Invalid webhook signature');
  }

  // Acknowledge immediately, then process — Flutterwave expects a fast 200 response.
  res.status(200).json({ success: true });
  await paymentsService.handleFlutterwaveWebhook(req.body);
});

const router = Router();
router.post('/webhooks/flutterwave', webhookHandler);

export default router;
