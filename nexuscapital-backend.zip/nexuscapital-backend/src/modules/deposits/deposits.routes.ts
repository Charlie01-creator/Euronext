import { v4 as uuid } from 'uuid';
import { z } from 'zod';
import { Router, Request, Response } from 'express';
import { prisma } from '../../lib/prisma';
import { requireAuth } from '../../middleware/auth.middleware';
import { validate } from '../../middleware/validate.middleware';
import { requireIdempotencyKey } from '../../middleware/idempotency.middleware';
import { catchAsync } from '../../utils/catchAsync';
import { ApiError } from '../../utils/ApiError';
import { env } from '../../config/env';
import * as flutterwave from '../payments/flutterwave.provider';
import * as currencyService from '../currency/currency.service';

// ── Validation ───────────────────────────────────────────────────
const createDepositSchema = z.object({
  body: z.object({
    amount: z.number().positive('Amount must be greater than zero'),
    currency: z.string().length(3).default('USD'),
    method: z.enum(['MTN_MOBILE_MONEY', 'AIRTEL_MONEY', 'CARD', 'BANK_TRANSFER']),
    phone: z.string().min(7).max(20).optional(),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

const MINIMUM_DEPOSIT_USD = 10;

// ── Service ──────────────────────────────────────────────────────
async function createDeposit(userId: string, input: z.infer<typeof createDepositSchema>['body']) {
  const isMobileMoney = input.method === 'MTN_MOBILE_MONEY' || input.method === 'AIRTEL_MONEY';
  if (isMobileMoney && !input.phone) {
    throw ApiError.badRequest('Phone number is required for mobile money deposits');
  }

  const amountUsd = await currencyService.toUsd(input.amount, input.currency);
  if (amountUsd < MINIMUM_DEPOSIT_USD) {
    throw ApiError.badRequest(`Minimum deposit is ${MINIMUM_DEPOSIT_USD} USD equivalent`);
  }

  const user = await prisma.user.findUniqueOrThrow({ where: { id: userId } });
  const txRef = `dep_${userId}_${uuid().slice(0, 10)}`;

  const transaction = await prisma.transaction.create({
    data: {
      userId,
      type: 'DEPOSIT',
      status: 'PENDING',
      method: input.method,
      amountUsd,
      currency: input.currency,
      providerRef: txRef,
      destination: input.phone ? { phone: input.phone } : undefined,
    },
  });

  if (isMobileMoney) {
    const charge = await flutterwave.chargeMobileMoney({
      amountUsd,
      currency: input.currency,
      phone: input.phone!,
      email: user.email,
      fullName: user.fullName,
      network: input.method === 'MTN_MOBILE_MONEY' ? 'MTN' : 'AIRTEL',
      txRef,
    });
    return { transaction, redirectUrl: null, providerStatus: charge.data.status };
  }

  const checkout = await flutterwave.createHostedCheckout({
    amountUsd,
    currency: input.currency,
    email: user.email,
    fullName: user.fullName,
    txRef,
    redirectUrl: `${env.APP_BASE_URL}/nexus-dashboard-mobile.html`,
  });
  return { transaction, redirectUrl: checkout.data.link, providerStatus: 'pending' };
}

async function listDeposits(userId: string) {
  return prisma.transaction.findMany({
    where: { userId, type: 'DEPOSIT' },
    orderBy: { createdAt: 'desc' },
    take: 50,
  });
}

// ── Controller ───────────────────────────────────────────────────
/**
 * @openapi
 * /deposits:
 *   post:
 *     tags: [Deposits]
 *     summary: Initiate a deposit via MTN, Airtel, Card, or Bank Transfer
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - { in: header, name: Idempotency-Key, required: true, schema: { type: string } }
 *     responses:
 *       201: { description: Deposit initiated }
 *   get:
 *     tags: [Deposits]
 *     summary: List the current user's deposit history
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Deposit list }
 */
const createHandler = catchAsync(async (req: Request, res: Response) => {
  const result = await createDeposit(req.user!.id, req.body);
  res.status(201).json({ success: true, data: result });
});

const listHandler = catchAsync(async (req: Request, res: Response) => {
  const deposits = await listDeposits(req.user!.id);
  res.json({ success: true, data: deposits });
});

// ── Routes ───────────────────────────────────────────────────────
const router = Router();
router.use(requireAuth);
router.get('/', listHandler);
router.post('/', requireIdempotencyKey, validate(createDepositSchema), createHandler);

export default router;
