import { v4 as uuid } from 'uuid';
import { z } from 'zod';
import { Router, Request, Response } from 'express';
import { prisma } from '../../lib/prisma';
import { requireAuth } from '../../middleware/auth.middleware';
import { validate } from '../../middleware/validate.middleware';
import { requireIdempotencyKey } from '../../middleware/idempotency.middleware';
import { catchAsync } from '../../utils/catchAsync';
import { ApiError } from '../../utils/ApiError';
import * as flutterwave from '../payments/flutterwave.provider';
import * as currencyService from '../currency/currency.service';
import { createNotification } from '../notifications/notifications.service';

// ── Validation ───────────────────────────────────────────────────
const createWithdrawalSchema = z
  .object({
    body: z.object({
      amount: z.number().positive('Amount must be greater than zero'),
      currency: z.string().length(3).default('USD'),
      method: z.enum(['MTN_MOBILE_MONEY', 'AIRTEL_MONEY', 'BANK_TRANSFER']), // no CARD — card payouts aren't a real thing
      phone: z.string().min(7).max(20).optional(),
      bankCode: z.string().optional(),
      accountNumber: z.string().optional(),
      accountHolderName: z.string().optional(),
    }),
    query: z.object({}).optional(),
    params: z.object({}).optional(),
  })
  .refine((data) => data.body.method === 'BANK_TRANSFER' || Boolean(data.body.phone), {
    message: 'Phone number is required for mobile money withdrawals',
    path: ['body', 'phone'],
  })
  .refine(
    (data) =>
      data.body.method !== 'BANK_TRANSFER' ||
      (Boolean(data.body.accountNumber) && Boolean(data.body.accountHolderName)),
    { message: 'Bank account number and account holder name are required', path: ['body', 'accountNumber'] }
  );

const MINIMUM_WITHDRAWAL_USD = 10;

// ── Service ──────────────────────────────────────────────────────
async function createWithdrawal(userId: string, input: z.infer<typeof createWithdrawalSchema>['body']) {
  const amountUsd = await currencyService.toUsd(input.amount, input.currency);
  if (amountUsd < MINIMUM_WITHDRAWAL_USD) {
    throw ApiError.badRequest(`Minimum withdrawal is ${MINIMUM_WITHDRAWAL_USD} USD equivalent`);
  }

  const user = await prisma.user.findUniqueOrThrow({ where: { id: userId } });
  if (Number(user.balanceUsd) < amountUsd) {
    throw ApiError.badRequest('Insufficient balance for this withdrawal');
  }

  const reference = `wd_${userId}_${uuid().slice(0, 10)}`;
  const destination =
    input.method === 'BANK_TRANSFER'
      ? { bankCode: input.bankCode, accountNumber: input.accountNumber, accountHolderName: input.accountHolderName }
      : { phone: input.phone };

  // Deduct up-front so the same funds can't be withdrawn twice while the payout is in flight.
  // The webhook refunds this automatically if Flutterwave reports the payout failed.
  const transaction = await prisma.$transaction(async (tx) => {
    await tx.user.update({ where: { id: userId }, data: { balanceUsd: { decrement: amountUsd } } });
    return tx.transaction.create({
      data: {
        userId,
        type: 'WITHDRAWAL',
        status: 'PENDING',
        method: input.method,
        amountUsd,
        currency: input.currency,
        providerRef: reference,
        destination,
      },
    });
  });

  try {
    await flutterwave.initiatePayout({
      amountUsd,
      currency: input.currency,
      narration: 'NexusCapital withdrawal',
      reference,
      phone: input.method === 'BANK_TRANSFER' ? undefined : input.phone,
      network: input.method === 'MTN_MOBILE_MONEY' ? 'MTN' : input.method === 'AIRTEL_MONEY' ? 'AIRTEL' : undefined,
      accountNumber: input.accountNumber,
      bankCode: input.bankCode,
    });
  } catch (err) {
    // Provider rejected the payout outright (bad account details etc) — refund immediately rather than waiting on a webhook that will never arrive.
    await prisma.$transaction(async (tx) => {
      await tx.user.update({ where: { id: userId }, data: { balanceUsd: { increment: amountUsd } } });
      await tx.transaction.update({ where: { id: transaction.id }, data: { status: 'FAILED', failureReason: (err as Error).message } });
    });
    throw err;
  }

  await createNotification({
    userId,
    type: 'WITHDRAWAL',
    icon: 'fa-money-bill-transfer',
    color: 'gold',
    title: 'Withdrawal requested',
    description: `Your withdrawal of $${amountUsd.toLocaleString()} is being processed and typically arrives within 2 hours.`,
  });

  return transaction;
}

async function listWithdrawals(userId: string) {
  return prisma.transaction.findMany({
    where: { userId, type: 'WITHDRAWAL' },
    orderBy: { createdAt: 'desc' },
    take: 50,
  });
}

// ── Controller ───────────────────────────────────────────────────
/**
 * @openapi
 * /withdrawals:
 *   post:
 *     tags: [Withdrawals]
 *     summary: Request a withdrawal to MTN, Airtel, or a bank account
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - { in: header, name: Idempotency-Key, required: true, schema: { type: string } }
 *     responses:
 *       201: { description: Withdrawal requested }
 *   get:
 *     tags: [Withdrawals]
 *     summary: List the current user's withdrawal history
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Withdrawal list }
 */
const createHandler = catchAsync(async (req: Request, res: Response) => {
  const result = await createWithdrawal(req.user!.id, req.body);
  res.status(201).json({ success: true, data: result });
});

const listHandler = catchAsync(async (req: Request, res: Response) => {
  const withdrawals = await listWithdrawals(req.user!.id);
  res.json({ success: true, data: withdrawals });
});

// ── Routes ───────────────────────────────────────────────────────
const router = Router();
router.use(requireAuth);
router.get('/', listHandler);
router.post('/', requireIdempotencyKey, validate(createWithdrawalSchema), createHandler);

export default router;
