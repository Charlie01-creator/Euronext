import { Request, Response } from 'express';
import { catchAsync } from '../../utils/catchAsync';
import * as notificationsService from './notifications.service';

/**
 * @openapi
 * /notifications:
 *   get:
 *     tags: [Notifications]
 *     summary: List the current user's notifications (most recent first)
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       200: { description: Notification list with unread count }
 */
export const listHandler = catchAsync(async (req: Request, res: Response) => {
  const [items, unread] = await Promise.all([
    notificationsService.listNotifications(req.user!.id),
    notificationsService.unreadCount(req.user!.id),
  ]);
  res.json({ success: true, data: { items, unreadCount: unread } });
});

/**
 * @openapi
 * /notifications/{id}/read:
 *   patch:
 *     tags: [Notifications]
 *     summary: Mark a single notification as read
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       204: { description: Marked read }
 */
export const markOneReadHandler = catchAsync(async (req: Request, res: Response) => {
  await notificationsService.markOneRead(req.user!.id, req.params.id);
  res.status(204).send();
});

/**
 * @openapi
 * /notifications/read-all:
 *   patch:
 *     tags: [Notifications]
 *     summary: Mark every notification as read
 *     security: [{ bearerAuth: [] }]
 *     responses:
 *       204: { description: All marked read }
 */
export const markAllReadHandler = catchAsync(async (req: Request, res: Response) => {
  await notificationsService.markAllRead(req.user!.id);
  res.status(204).send();
});
